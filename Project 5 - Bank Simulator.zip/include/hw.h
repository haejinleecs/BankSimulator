#ifndef __HW6_H
#define __HW6_H

#include "atm.h"
#include "bank.h"
#include "command.h"
#include "errors.h"
#include "trace.h"

#endif
